#!/bin/bash

SELF=$(basename "$0")

if [ "$SELF" = "template_task.sh" ]; then
	echo "я бригадир, сам не работаю"
	exit 1
fi

WORKDIR=$(cd "$(dirname "$0")" && pwd)
LOG="$WORKDIR/report_${SELF}.log"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $*" >> "$LOG"; }

log "Скрипт запущен"

# канал для ответа кукушки
ANSWER="/tmp/run/answer.$$"
mkfifo "$ANSWER"

# запрос к кукушке
echo "${SELF}[$$]: how much time do I have?" > /tmp/run/cuckoo.pid

# читаем ответ
read -r N < "$ANSWER"
rm -f "$ANSWER"

sleep "$N"

log "Скрипт завершился, работал $N секунд."
