#!/bin/bash

PIPE=/tmp/run/cuckoo.pid
LOG="$(cd "$(dirname "$0")" && pwd)/cuckoo.log"

mkdir -p /tmp/run
[ -p "$PIPE" ] || mkfifo "$PIPE"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

shutdown() {
    log "Shutdown!"
    rm -f "$PIPE"
    exit 0
}
trap shutdown SIGTERM

log "Startup!"

while true; do
	if read -r line < "$PIPE"; then
		if [[ "$line" =~ ^(.+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
			name="${BASH_REMATCH[1]}"
			pid="${BASH_REMATCH[2]}"
			n=$(( RANDOM % 9 + 2 ))
			answer="/tmp/run/answer.$pid"
			if [ -p "$answer" ]; then
				echo "$n" > "$answer"
			fi
			log "${name}[${pid}] $n"
		fi
	fi
done
