#!/bin/bash

WORKDIR=$(cd "$(dirname "$0")" && pwd)
CONF="$WORKDIR/observer.conf"
LOG="$WORKDIR/observer.log"

cd "$WORKDIR" || exit 1

while read -r task; do
	# пропускаем пустые строки и комментарии
	[ -z "$task" ] && continue
	[[ "$task" == \#* ]] && continue

	running=0
	for d in /proc/[0-9]*; do
		cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
		if [[ "$cmd" == *"$task"* ]]; then
			running=1
			break
		fi
	done

	if [ "$running" -eq 0 ]; then
		nohup "$WORKDIR/$task" >/dev/null 2>&1 &
		echo "$(date '+%Y-%m-%d %H:%M:%S') перезапущена задача $task (PID $!)" >> "$LOG"
	fi
done < "$CONF"
